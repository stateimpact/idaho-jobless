function noSpecs() {
	it('should have specs', function() {
		expect('specs').toBe();
	});
}