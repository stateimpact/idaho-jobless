
L.CRS = {
	latLngToPoint: function(/*LatLng*/ latlng, /*Number*/ scale)/*-> Point*/ {
		var projectedPoint = this.projection.project(latlng);
		return this.transformation._transform(projectedPoint, scale);
	},
	
	pointToLatLng: function(/*Point*/ point, /*Number*/ scale, /*(optional) Boolean*/ unbounded)/*-> LatLng*/ {
		var untransformedPoint = this.transformation.untransform(point, scale);
		return this.projection.unproject(untransformedPoint, unbounded); 
		//TODO get rid of 'unbounded' everywhere
	},
	
	project: function(latlng) {
		return this.projection.project(latlng);
	}
};